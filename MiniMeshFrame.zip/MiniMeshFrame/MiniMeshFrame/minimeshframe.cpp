#include "minimeshframe.h"

MiniMeshFrame::MiniMeshFrame(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

MiniMeshFrame::~MiniMeshFrame()
{

}
