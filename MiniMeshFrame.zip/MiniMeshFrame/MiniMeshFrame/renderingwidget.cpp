#include "renderingwidget.h"
#include <QKeyEvent>
#include <QColorDialog>
#include <QFileDialog>
#include <iostream>
#include <QtWidgets/QMenu>
#include <QtWidgets/QAction>
#include <QTextCodec>
#include <GL/GLU.h>
#include <GL/glut.h>
#include <algorithm>
#include "mainwindow.h"
#include "ArcBall.h"
#include "globalFunctions.h"
#include "qmessagebox.h"

#pragma comment(lib, "glut64.lib")

RenderingWidget::RenderingWidget(QWidget *parent, MainWindow* mainwindow)
: QGLWidget(parent), ptr_mainwindow_(mainwindow), eye_distance_(150.0),
has_lighting_(false), is_draw_point_(true), is_draw_edge_(false), is_draw_face_(false), is_draw_texture_(false)
{
	ptr_arcball_ = new CArcBall(width(), height());
	//ptr_mesh_ = new Mesh3D();

	is_load_texture_ = false;
	is_draw_axes_ = false;

	eye_goal_[0] = eye_goal_[1] = eye_goal_[2] = 0.0;
	eye_direction_[0] = eye_direction_[1] = 0.0;
	eye_direction_[2] = 1.0;
}

RenderingWidget::~RenderingWidget()
{
	SafeDelete(ptr_arcball_);
	//SafeDelete(ptr_mesh_);
}

void RenderingWidget::initializeGL()
{
	glClearColor(0.3, 0.3, 0.3, 0.0);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_DOUBLEBUFFER);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POLYGON_SMOOTH);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_DEPTH_TEST);
	glClearDepth(1);

	SetLight();

}

void RenderingWidget::resizeGL(int w, int h)
{
	h = (h == 0) ? 1 : h;

	ptr_arcball_->reSetBound(w, h);

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0, GLdouble(w) / GLdouble(h), 0.001, 1000);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void RenderingWidget::paintGL()
{
	glShadeModel(GL_SMOOTH);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (has_lighting_)
	{
		SetLight();
	}
	else
	{
		glDisable(GL_LIGHTING);
		glDisable(GL_LIGHT0);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	register vec eyepos = eye_distance_*eye_direction_;
	gluLookAt(eyepos[0], eyepos[1], eyepos[2],
		eye_goal_[0], eye_goal_[1], eye_goal_[2],
		0.0, 1.0, 0.0);
	glPushMatrix();

	glMultMatrixf(ptr_arcball_->GetBallMatrix());

	Render();
	glPopMatrix();
}

void RenderingWidget::timerEvent(QTimerEvent * e)
{
	updateGL();
}

void RenderingWidget::mousePressEvent(QMouseEvent *e)
{
	switch (e->button())
	{
	case Qt::LeftButton:
		ptr_arcball_->MouseDown(e->pos());
		break;
	case Qt::MidButton:
		current_position_ = e->pos();
		break;
	default:
		break;
	}

	updateGL();
}
void RenderingWidget::mouseMoveEvent(QMouseEvent *e)
{
	switch (e->buttons())
	{
		setCursor(Qt::ClosedHandCursor);
	case Qt::LeftButton:
		ptr_arcball_->MouseMove(e->pos());
		break;
	case Qt::MidButton:
		eye_goal_[0] -= 4.0*GLfloat(e->x() - current_position_.x()) / GLfloat(width());
		eye_goal_[1] += 4.0*GLfloat(e->y() - current_position_.y()) / GLfloat(height());
		current_position_ = e->pos();
		break;
	default:
		break;
	}

	updateGL();
}
void RenderingWidget::mouseDoubleClickEvent(QMouseEvent *e)
{
	switch (e->button())
	{
	case Qt::LeftButton:
		break;
	default:
		break;
	}
	updateGL();
}
void RenderingWidget::mouseReleaseEvent(QMouseEvent *e)
{
	switch (e->button())
	{
	case Qt::LeftButton:
		ptr_arcball_->MouseUp(e->pos());
		setCursor(Qt::ArrowCursor);
		break;

	case Qt::RightButton:
		break;
	default:
		break;
	}
}

void RenderingWidget::wheelEvent(QWheelEvent *e)
{
	eye_distance_ += e->delta()*0.03;
	eye_distance_ = eye_distance_ < 0 ? 0 : eye_distance_;

	updateGL();
}

void RenderingWidget::keyPressEvent(QKeyEvent *e)
{
	switch (e->key())
	{
	case Qt::Key_A:
		break;
	default:
		break;
	}
}

void RenderingWidget::keyReleaseEvent(QKeyEvent *e)
{
	switch (e->key())
	{
	case Qt::Key_A:
		break;
	default:
		break;
	}
}

void RenderingWidget::Render()
{
	DrawAxes(is_draw_axes_);

	DrawPoints(is_draw_point_);
	DrawEdge(is_draw_edge_);
	DrawFace(is_draw_face_);
	DrawTexture(is_draw_texture_);
}

void RenderingWidget::SetLight()
{
	static GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	static GLfloat mat_shininess[] = { 50.0 };
	static GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
	static GLfloat white_light[] = { 0.8, 0.8, 0.8, 1.0 };
	static GLfloat lmodel_ambient[] = { 0.3, 0.3, 0.3, 1.0 };

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
}

void RenderingWidget::SetBackground()
{
	QColor color = QColorDialog::getColor(Qt::white, this, tr("background color"));
	GLfloat r = (color.red()) / 255.0f;
	GLfloat g = (color.green()) / 255.0f;
	GLfloat b = (color.blue()) / 255.0f;
	GLfloat alpha = color.alpha() / 255.0f;
	glClearColor(r, g, b, alpha);
	updateGL();
}

void RenderingWidget::ReadMesh()
{
	QString filename = QFileDialog::
		getOpenFileName(this, tr("Read Mesh"),
		"..", tr("Meshes (*.obj)"));

	if (filename.isEmpty())
	{
		emit(operatorInfo(QString("Read Mesh Failed!")));
		return;
	}
	//����·��֧��
	QTextCodec *code = QTextCodec::codecForName("gd18030");
	QTextCodec::setCodecForLocale(code);

	QByteArray byfilename = filename.toLocal8Bit();

	bool result = OpenMesh::IO::read_mesh(mesh, filename.toStdString());
	if (result == false)
	{
		printf("��ȡ����ʧ�ܣ�\n");
		return;
	}
	verts.clear();
	new_position.clear();
	for (MyMesh::VertexIter it = mesh.vertices_begin(); it != mesh.vertices_end(); ++it)
	{
		verts.push_back(it.handle());
	}

	//ptr_mesh_->LoadFromOBJFile(byfilename.data());
	//verts.clear();
	//verts = *(ptr_mesh_->get_vertex_list());

	////	m_pMesh->LoadFromOBJFile(filename.toLatin1().data());
	//emit(operatorInfo(QString("Read Mesh from") + filename + QString(" Done")));
	//emit(meshInfo(ptr_mesh_->num_of_vertex_list(), ptr_mesh_->num_of_edge_list(), ptr_mesh_->num_of_face_list()));
	//updateGL();

	emit(operatorInfo(QString("Read Mesh from") + filename + QString(" Done")));
	emit(meshInfo(mesh.n_vertices(), mesh.n_edges(), mesh.n_faces()));
	updateGL();
}

void RenderingWidget::WriteMesh()
{
	if (mesh.n_vertices() == 0)
	{
		emit(QString("The Mesh is Empty !"));
		return;
	}
	QString filename = QFileDialog::
		getSaveFileName(this, tr("Write Mesh"),
		"..", tr("Meshes (*.obj)"));

	if (filename.isEmpty())
		return;

	//ptr_mesh_->WriteToOBJFile(filename.toLatin1().data());
	OpenMesh::IO::write_mesh(mesh, filename.toStdString());

	emit(operatorInfo(QString("Write Mesh to ") + filename + QString(" Done")));
}

void RenderingWidget::LoadTexture()
{
	QString filename = QFileDialog::getOpenFileName(this, tr("Load Texture"),
		"..", tr("Images(*.bmp *.jpg *.png *.jpeg)"));
	if (filename.isEmpty())
	{
		emit(operatorInfo(QString("Load Texture Failed!")));
		return;
	}


	glGenTextures(1, &texture_[0]);
	QImage tex1, buf;
	if (!buf.load(filename))
	{
		//        QMessageBox::warning(this, tr("Load Fialed!"), tr("Cannot Load Image %1").arg(filenames.at(0)));
		emit(operatorInfo(QString("Load Texture Failed!")));
		return;
		/*
		QImage dummy(128, 128, QImage::Format_ARGB32);
		dummy.fill(Qt::green);
		buf = dummy;
		*/
	}

	tex1 = QGLWidget::convertToGLFormat(buf);
	glBindTexture(GL_TEXTURE_2D, texture_[0]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, tex1.width(), tex1.height(),
		GL_RGBA, GL_UNSIGNED_BYTE, tex1.bits());

	is_load_texture_ = true;
	emit(operatorInfo(QString("Load Texture from ") + filename + QString(" Done")));
}

void RenderingWidget::CheckDrawPoint(bool bv)
{
	is_draw_point_ = bv;
	updateGL();
}
void RenderingWidget::CheckDrawEdge(bool bv)
{
	is_draw_edge_ = bv;
	updateGL();
}
void RenderingWidget::CheckDrawFace(bool bv)
{
	is_draw_face_ = bv;
	updateGL();
}
void RenderingWidget::CheckLight(bool bv)
{
	has_lighting_ = bv;
	updateGL();
}
void RenderingWidget::CheckDrawTexture(bool bv)
{
	is_draw_texture_ = bv;
	if (is_draw_texture_)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);

	updateGL();
}
void RenderingWidget::CheckDrawAxes(bool bV)
{
	is_draw_axes_ = bV;
	updateGL();
}

void RenderingWidget::DrawAxes(bool bV)
{
	if (!bV)
		return;
	//x axis
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0.7, 0.0, 0.0);
	glEnd();
	glPushMatrix();
	glTranslatef(0.7, 0, 0);
	glRotatef(90, 0.0, 1.0, 0.0);
	glutSolidCone(0.02, 0.06, 20, 10);
	glPopMatrix();

	//y axis
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0.0, 0.7, 0.0);
	glEnd();

	glPushMatrix();
	glTranslatef(0.0, 0.7, 0);
	glRotatef(90, -1.0, 0.0, 0.0);
	glutSolidCone(0.02, 0.06, 20, 10);
	glPopMatrix();

	//z axis
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0.0, 0.0, 0.7);
	glEnd();
	glPushMatrix();
	glTranslatef(0.0, 0, 0.7);
	glutSolidCone(0.02, 0.06, 20, 10);
	glPopMatrix();

	glColor3f(1.0, 1.0, 1.0);
}

//std::vector<HE_vert*>* RenderingWidget::Extract_Boundary(std::vector<HE_vert*> verts)
//{
//	std::vector<HE_vert*>* boundary_points=new std::vector<HE_vert *>;
//	const std::vector<HE_face *>& faces = *(ptr_mesh_->get_faces_list());
//
//	//�������ϵ�һ�㽨�������ڽ�������������
//	std::vector<HE_vert *> triangles;//��ʱ��ŵ�ǰ�����������������
//	triangles.reserve(3);
//	std::vector<HE_vert *>::iterator it;
//	for (size_t i = 0; i != ptr_mesh_->num_of_vertex_list(); ++i)
//	{
//		std::vector<HE_vert *> Temp;//��ʱ������
//		for (size_t j = 0; j != faces.size(); ++j)
//		{
//			faces.at(j)->face_verts(triangles);
//			it = std::find(triangles.begin(), triangles.end(), verts[i]);
//			if (it != triangles.end())//˵����ǰ��������Ϊ�õ���ڽ���������
//			{
//				for (size_t k = 0; k != 3; ++k)
//				{
//					if (triangles[k] != verts[i])
//					{
//						it = std::find(Temp.begin(), Temp.end(), triangles[k]);
//						if (it != Temp.end())
//						{
//							Temp.erase(it);
//						}
//						else
//						{
//							Temp.push_back(triangles[k]);
//						}
//					}
//				}
//			}
//		}
//		if (Temp.size() != 0)
//		{
//			boundary_points->push_back(verts[i]);
//		}
//	}
//
//	return boundary_points;
//}

void RenderingWidget::Minimal_Surface()
{
	//std::vector<HE_vert*>* boundary_points = Extract_Boundary(verts);
	if (verts.size() > 0)
	{
		for (int j = 0; j < 1000; j++)//�ظ�����
		{
			for (size_t i = 0; i != verts.size(); ++i)
			{
				if (!mesh.is_boundary(verts[i]))
				{
					auto p = MyMesh::Point(0, 0, 0);
					int neighborIdx_size = 0;
					for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
					{
						p -= mesh.point(verts[i]) - mesh.point(it);
						neighborIdx_size++;
					}
					p /= neighborIdx_size;
					p *= 0.3;
					new_position[verts[i]] = mesh.point(verts[i]) + p;
				}
			}
			for (size_t i = 0; i != verts.size(); ++i)
			{
				if (!mesh.is_boundary(verts[i]))
				{
					mesh.set_point(verts[i], new_position[verts[i]]);
				}
			}
		}

		glBegin(GL_POINTS);
		//for (size_t i = 0; i != mesh.n_vertices(); ++i)
		//{
		//	glNormal3fv(verts[i]->normal().data());
		//	glVertex3fv(verts[i]->position().data());

		//}
		for (MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
		{
			glVertex3fv(mesh.point(*v_it).data());
		}

		glEnd();
		updateGL();
		std::cout << "Successfully edited!" << std::endl;
	}
	else
	{
		QMessageBox::about(this, tr("Warning"), tr("Please read an obj file first!"));
	}
}

void RenderingWidget::Minimal_Surface_Global()
{
	//std::vector<HE_vert*>* boundary_points = Extract_Boundary(verts);
	if (verts.size() > 0)
	{
		SparseMatrix<double> A(verts.size(), verts.size());
		QVector<Triplet<double>> triplets;
		QVector<int> row, column;
		QVector<double> value;
		VectorXd conX = VectorXd::Zero(verts.size());
		VectorXd conY = VectorXd::Zero(verts.size());
		VectorXd conZ = VectorXd::Zero(verts.size());

		//����ϵ������ͳ�������
		for (size_t i = 0; i != verts.size(); ++i)
		{
			if (!mesh.is_boundary(verts[i]))
			{
				int neighborIdx_size = 0;
				for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
				{
					row.push_back(i);
					column.push_back(it.handle().idx());
					value.push_back(-1);
					neighborIdx_size++;
				}
				row.push_back(i);
				column.push_back(i);
				value.push_back(neighborIdx_size);
			}
			else
			{
				row.push_back(i);
				column.push_back(i);
				value.push_back(1);
				conX(i) = mesh.point(verts[i])[0];
				conY(i) = mesh.point(verts[i])[1];
				conZ(i) = mesh.point(verts[i])[2];
			}
		}

		for (int i = 0; i < row.length(); i++)
		{
			triplets.push_back(Triplet<double>(row[i], column[i], value[i]));
		}
		A.setFromTriplets(triplets.begin(), triplets.end());
		linearSolver.compute(A);

		//�ж�ϵ������A�Ƿ����ȣ��������Ƿ���Ψһ��
		//FullPivLU<MatrixXd> lu(A);
		//std::cout << "m=" << verts.size()<< ",the rank of A is found to be " << lu.rank() << "." << std::endl;

		//��С�������
		VectorXd x1 = linearSolver.solve(conX);
		VectorXd x2 = linearSolver.solve(conY);
		VectorXd x3 = linearSolver.solve(conZ);	

		if (linearSolver.info() != Success)
		{
			printf("Solving failed!\n");
			return;
		}

		//��������
		for (size_t i = 0; i != verts.size(); ++i)
		{
			mesh.set_point(verts[i], OpenMesh::DefaultTraits::Point(x1(i), x2(i), x3(i)));
		}

		glBegin(GL_POINTS);

		for (MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
		{
			glVertex3fv(mesh.point(*v_it).data());
		}
		glEnd();
		updateGL();
		std::cout << "Successfully edited!" << std::endl;
	}
	else
	{
		QMessageBox::about(this, tr("Warning"), tr("Please read an obj file first!"));
	}
}

bool RenderingWidget::IsNeighbor(MyMesh::VertexHandle it1, MyMesh::VertexHandle idx)
{
	for (auto it2 = mesh.vv_begin(it1); it2 != mesh.vv_end(it1); ++it2)
	{
		if (idx == it2.handle())
		{
			return true;
		}
	}
	return false;
}

void RenderingWidget::ParameterBorderVertex(std::vector<MyMesh::VertexHandle>& temp_m_BorderVertexIdx)
{
	if (temp_m_BorderVertexIdx.size() < 3)
	{
		return;
	}
	//���߽�㰴�̶��������У�˳ʱ�������ʱ�룩
	std::vector<MyMesh::VertexHandle> m_BorderVertexIdx, corners;
	std::vector<MyMesh::VertexHandle>::iterator it;
	bool isNeighbor;
	size_t i=0;
	m_BorderVertexIdx.push_back(temp_m_BorderVertexIdx[0]);
	int length = temp_m_BorderVertexIdx.size();

	while (m_BorderVertexIdx.size() < length)
	{
		int temp_i = i;
		for (size_t j = 0; j != temp_m_BorderVertexIdx.size(); ++j)
		{
			isNeighbor = IsNeighbor(temp_m_BorderVertexIdx[i], temp_m_BorderVertexIdx[j]);
			if (isNeighbor)//�ҵ��ڵ�
			{
				it = std::find(m_BorderVertexIdx.begin(), m_BorderVertexIdx.end(), temp_m_BorderVertexIdx[j]);
				if (it == m_BorderVertexIdx.end())//�ж��ڵ��Ƿ��Ѿ������ӽ�����
				{
					it = std::find(corners.begin(), corners.end(), temp_m_BorderVertexIdx[j]);
					if (it == corners.end())//�ж��Ƿ��ǽǵ�
					{
						m_BorderVertexIdx.push_back(temp_m_BorderVertexIdx[j]);
						i = j;
						break;
					}
				}
			}
		}

		//�����ǵ��Ӱ��
		if (temp_i == i)
		{
			m_BorderVertexIdx.pop_back();
			corners.push_back(temp_m_BorderVertexIdx[i]);
			it=std::find(temp_m_BorderVertexIdx.begin(), temp_m_BorderVertexIdx.end(), m_BorderVertexIdx[m_BorderVertexIdx.size() - 1]);
			i = it - temp_m_BorderVertexIdx.begin();
			length--;
			length--;
		}
	}

	//����߽��ܳ���
	double m_SumBorderLength = 0;
	point v1v2;
	std::vector<double> VertexU(m_BorderVertexIdx.size(), 0.0);//�߽綥��Ļ�������������
	for (int i = 1; i<m_BorderVertexIdx.size(); i++)
	{
		v1v2 = point((mesh.point(m_BorderVertexIdx[i]) - mesh.point(m_BorderVertexIdx[i - 1]))[0], (mesh.point(m_BorderVertexIdx[i]) - mesh.point(m_BorderVertexIdx[i - 1]))[1], (mesh.point(m_BorderVertexIdx[i]) - mesh.point(m_BorderVertexIdx[i - 1]))[2]);
		m_SumBorderLength += len(v1v2);
		VertexU[i] = m_SumBorderLength;
	}
	v1v2 = point((mesh.point(m_BorderVertexIdx[m_BorderVertexIdx.size() - 1]) - mesh.point(m_BorderVertexIdx[0]))[0], (mesh.point(m_BorderVertexIdx[m_BorderVertexIdx.size() - 1]) - mesh.point(m_BorderVertexIdx[0]))[1], (mesh.point(m_BorderVertexIdx[m_BorderVertexIdx.size() - 1]) - mesh.point(m_BorderVertexIdx[0]))[2]);
	m_SumBorderLength += len(v1v2);
	for (int i = 0; i<VertexU.size(); i++)
	{
		VertexU[i] /= m_SumBorderLength;
	}
	//�����β�����
	double unionscal = 0.25;
	for (int i = 0; i<VertexU.size(); i++)
	{
		if (unionscal > VertexU[i])
		{
			new_position[m_BorderVertexIdx[i]]= MyMesh::Point(VertexU[i] * 4.0, 0.0, 0.0);
		}
		else if (unionscal*2.0>VertexU[i])
		{
			new_position[m_BorderVertexIdx[i]] = MyMesh::Point(1.0, (VertexU[i] - unionscal)*4.0, 0.0);
		}
		else if (unionscal*3.0>VertexU[i])
		{
			new_position[m_BorderVertexIdx[i]] = MyMesh::Point((unionscal*3.0 - VertexU[i])*4.0, 1.0, 0.0);
		}
		else if (unionscal*4.0>VertexU[i])
		{
			new_position[m_BorderVertexIdx[i]] = MyMesh::Point(0.0, (1.0 - VertexU[i])*4.0, 0.0);
		}
	}
}

void RenderingWidget::Parameterize_Uniform()
{
	parameterizetype = parameterize_uniform;
	Parameterize();
}

double RenderingWidget::Sum_W(int p)
{
	double sum_w = 0;
	for (auto it = mesh.vv_begin(verts[p]); it != mesh.vv_end(verts[p]); ++it)
	{
		sum_w += 1.0 / (abs(mesh.point(verts[p])[0] - mesh.point(it)[0]) + abs(mesh.point(verts[p])[1] - mesh.point(it)[1]) + abs(mesh.point(verts[p])[2] - mesh.point(it)[2]));
	}
	return sum_w;
}

void RenderingWidget::Parameterize_Specific()
{
	parameterizetype = parameterize_specific;
	Parameterize();
}

std::vector<float> RenderingWidget::Local_Parameterization(int p)
{
	int PNeighborNumber=0;
	std::vector<MyMesh::VertexHandle> PNeighbor;
	for (auto it = mesh.vv_begin(verts[p]); it != mesh.vv_end(verts[p]); ++it)
	{
		PNeighborNumber++;
		PNeighbor.push_back(it);
	}
	std::vector<float> AverageWeight(PNeighborNumber, 0.0);
	//P���ڽӶ�������  
	std::vector<MyMesh::VertexHandle> SortNeighbor;
	SortNeighbor.push_back(PNeighbor[0]);
	std::vector<MyMesh::VertexHandle>::iterator iter;
	iter = std::find(PNeighbor.begin(), PNeighbor.end(), PNeighbor[0]);
	PNeighbor.erase(iter);
	int fid;
	while (PNeighbor.size()>0)
	{
		auto it = mesh.vv_begin(SortNeighbor[SortNeighbor.size() - 1]);
		for (; it != mesh.vv_end(SortNeighbor[SortNeighbor.size() - 1]); ++it)
		{
			iter = std::find(PNeighbor.begin(), PNeighbor.end(), it);
			if (iter != PNeighbor.end())
			{
				break;
			}
		}
		if (it == mesh.vv_end(SortNeighbor[SortNeighbor.size() - 1]))
		{
			QMessageBox::about(this, tr("Warning"), tr("Parameterization failed,error code 001��"));
		}
		SortNeighbor.push_back(it);
		PNeighbor.erase(iter);
	}

	//��p����ڽӶ���չƽ����άƽ��,P��Ϊ����ԭ��  
	//����ÿ����ĽǶ�  
	std::vector<float> Angle2D(PNeighborNumber, 0.0);//����  
	Angle2D[0] = 0.0;
	float SumAngle = 0.0;
	for (int i = 1; i<SortNeighbor.size(); i++)
	{
		point pa = point((mesh.point(SortNeighbor[i - 1])-mesh.point(verts[p]))[0], (mesh.point(SortNeighbor[i - 1]) - mesh.point(verts[p]))[1], (mesh.point(SortNeighbor[i - 1]) - mesh.point(verts[p]))[2]);
		point pb = point((mesh.point(SortNeighbor[i])-mesh.point(verts[p]))[0], (mesh.point(SortNeighbor[i]) - mesh.point(verts[p]))[1], (mesh.point(SortNeighbor[i]) - mesh.point(verts[p]))[2]);
		float angle = (pa DOT pb) / (len(pa)*len(pb));
		SumAngle += acos(angle);
		Angle2D[i] = SumAngle;
	}
	point pa = point((mesh.point(SortNeighbor[PNeighborNumber - 1]) - mesh.point(verts[p]))[0], (mesh.point(SortNeighbor[PNeighborNumber - 1]) - mesh.point(verts[p]))[1], (mesh.point(SortNeighbor[PNeighborNumber - 1]) - mesh.point(verts[p]))[2]);
	point pb = point((mesh.point(SortNeighbor[0]) - mesh.point(verts[p]))[0], (mesh.point(SortNeighbor[0]) - mesh.point(verts[p]))[1], (mesh.point(SortNeighbor[0]) - mesh.point(verts[p]))[2]); 
	float angle = (pa DOT pb) / (len(pa)*len(pb));
	SumAngle += acos(angle);
	for (int i = 0; i<PNeighborNumber; i++)
	{
		Angle2D[i] = Angle2D[i] * 2.0*3.1415926 / SumAngle;
	}
	//���㼫����ľ��򳤶�  
	std::vector<float> Radius(PNeighborNumber, 0.0);
	for (int j = 0; j<PNeighborNumber; j++)
	{
		point pq = point((mesh.point(SortNeighbor[j]) - mesh.point(verts[p]))[0], (mesh.point(SortNeighbor[j]) - mesh.point(verts[p]))[1], (mesh.point(SortNeighbor[j]) - mesh.point(verts[p]))[2]); 
		Radius[j] = len(pq);
	}
	//�����ά����  
	std::vector<point> P2Dcoordinate(PNeighborNumber);
	point pSeed(0.0, 0.0, 0.0);
	for (int i = 0; i<PNeighborNumber; i++)
	{
		P2Dcoordinate[i][0] = 10 * Radius[i] * cos(Angle2D[i]);
		P2Dcoordinate[i][1] = 10 * Radius[i] * sin(Angle2D[i]);
		P2Dcoordinate[i][2] = 0.0;
	}
	//��������ڽӶ����Ȩֵ  
	int p1, p2, p3;
	point pp1, pp2, pp3;
	std::vector<std::vector<float>> Weight;
	Weight.resize(PNeighborNumber);
	for (int i = 0; i<PNeighborNumber; i++)
	{
		Weight[i].reserve(PNeighborNumber + 2);
	}
	for (int i = 0; i<PNeighborNumber; i++)
	{
		p3 = i;
		pp3 = P2Dcoordinate[i] - pSeed;
		float Inaccuracy = 10000.0;
		int accuratep1, accuratep2;
		float u = 0.0;
		float v = 0.0;
		float w = 0.0;
		for (int j = 0; j<PNeighborNumber; j++)
		{
			if (j<PNeighborNumber - 1)
			{
				p1 = j;
				pp1 = P2Dcoordinate[j] - pSeed;
				p2 = j + 1;
				pp2 = P2Dcoordinate[j + 1] - pSeed;
			}
			else
			{
				p1 = j;
				pp1 = P2Dcoordinate[j] - pSeed;
				p2 = 0;
				pp2 = P2Dcoordinate[0] - pSeed;
			}
			if ((p1 != p3) && (p2 != p3))
			{

				//�ж�P���Ƿ���������p1p2p3�ڲ�  
				point  p1p2 = P2Dcoordinate[p2] - P2Dcoordinate[p1];
				point  p1p3 = P2Dcoordinate[p3] - P2Dcoordinate[p1];
				float AreaP1PP2 = 0.5*len(pp1 CROSS pp2);//ͨ�����ȡģ�����������
				float AreaP2PP3 = 0.5*len(pp2 CROSS pp3);
				float AreaP3PP1 = 0.5*len(pp3 CROSS pp1);
				float AreaP1P2P3 = 0.5*len(p1p2 CROSS p1p3);
				float AreaSum = AreaP1PP2 + AreaP2PP3 + AreaP3PP1;

				if (Inaccuracy>(AreaSum - AreaP1P2P3))
				{
					Inaccuracy = AreaSum - AreaP1P2P3;
					accuratep1 = p1;
					accuratep2 = p2;
					u = AreaP2PP3 / AreaSum;
					v = AreaP3PP1 / AreaSum;
					w = AreaP1PP2 / AreaSum;
				}
			}//if  
		}//for  
		Weight[accuratep1].push_back(u);
		Weight[accuratep2].push_back(v);
		Weight[p3].push_back(w);
	}
	//����������ƽ��Ȩֵ,����Ȩֵ�Ǹ�������󶥵��˳�������  
	std::vector<float> AverageWeight0(PNeighborNumber, 0.0);
	for (int i = 0; i<PNeighborNumber; i++)
	{
		for (int j = 0; j<Weight[i].size(); j++)
		{
			AverageWeight0[i] += Weight[i][j];
		}
		AverageWeight0[i] = AverageWeight0[i] / PNeighborNumber;
	}
	//�ع�δ�����Ȩֵ  �����յ�Ȩֵ  
	PNeighbor.clear();
	for (auto it = mesh.vv_begin(verts[p]); it != mesh.vv_end(verts[p]); ++it)
	{
		PNeighbor.push_back(it);
	}
	for (int i = 0; i<PNeighborNumber; i++)
	{
		iter = std::find(PNeighbor.begin(), PNeighbor.end(), SortNeighbor[i]);
		if (iter == PNeighbor.end())
		{
			QMessageBox::about(this, tr("Warning"), tr("Parameterization failed,error code 002��"));
		}
		int dis = distance(PNeighbor.begin(), iter);
		AverageWeight[dis] = AverageWeight0[i];
	}
	return AverageWeight;
}

void RenderingWidget::Parameterize_Shape_Preserving()
{
	parameterizetype = parameterize_shape_preserving;
	Parameterize();
}

void RenderingWidget::Parameterize()
{
	if (verts.size() > 0)
	{
		int n = 0;//�Ǳ߽������
		QVector<Triplet<double>> triplets;
		QVector<int> row, column;
		QVector<double> value;
		QVector<double> u1, u2;
		std::vector<MyMesh::VertexHandle> m_BorderVertexIdx;
		int k1 = -1, k2 = -1;
		bool isNeighbor;
		int PNeighborNumber = 0;

		//��ȡ�߽��
		for (size_t i = 0; i != verts.size(); ++i)
		{
			if (mesh.is_boundary(verts[i]))
			{
				m_BorderVertexIdx.push_back(verts[i]);
			}
			else
			{
				n++;
			}
		}
		VectorXd b1 = VectorXd::Zero(n);
		VectorXd b2 = VectorXd::Zero(n);

		//�߽綥�������
		ParameterBorderVertex(m_BorderVertexIdx);

		std::vector<float> AverageWeight;
		double sum_w=0;

		//����ϵ������ͳ�������
		for (size_t i = 0; i != verts.size(); ++i)
		{
			if (!mesh.is_boundary(verts[i]))
			{
				k1++;
				if (parameterizetype == parameterize_specific)
				{
					sum_w = Sum_W(i);
				}
				if (parameterizetype == parameterize_shape_preserving)
				{
					AverageWeight = Local_Parameterization(i);
				}
				for (size_t j = 0; j != verts.size(); ++j)
				{
					isNeighbor = IsNeighbor(verts[i], verts[j]);
					if (!mesh.is_boundary(verts[j]))
					{
						k2++;
						if (k1 == k2)
						{
							row.push_back(k1);
							column.push_back(k2);
							value.push_back(1);
						}
						else
						{
							if (isNeighbor)
							{
								row.push_back(k1);
								column.push_back(k2);
								switch (parameterizetype)
								{
								case parameterize_uniform:
									PNeighborNumber = 0;
									for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
									{
										PNeighborNumber++;
									}
									value.push_back(-1.0 / PNeighborNumber);
									break;
								case parameterize_specific:
									value.push_back(-1.0 / (abs(mesh.point(verts[i])[0]- mesh.point(verts[j])[0]) + abs(mesh.point(verts[i])[1] - mesh.point(verts[j])[1]) + abs(mesh.point(verts[i])[2] - mesh.point(verts[j])[2])) / sum_w);
									break;
								case parameterize_shape_preserving:
									int idx = 0;
									for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
									{
										if (verts[j] == it) 
										{
											break;
										}
										idx++;
									}
									value.push_back(-AverageWeight[idx]);
									break;
								}
							}
						}
					}
					else
					{
						if (isNeighbor)
						{
							switch (parameterizetype)
							{
							case parameterize_uniform:
								PNeighborNumber = 0;
								for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
								{
									PNeighborNumber++;
								}
								b1(k1) += 1.0 / PNeighborNumber*new_position[verts[j]][0];
								b2(k1) += 1.0 / PNeighborNumber*new_position[verts[j]][1];
								break;
							case parameterize_specific:
								b1(k1) += 1.0 / (abs(mesh.point(verts[i])[0] - mesh.point(verts[j])[0]) + abs(mesh.point(verts[i])[1] - mesh.point(verts[j])[1]) + abs(mesh.point(verts[i])[2] - mesh.point(verts[j])[2])) / sum_w*new_position[verts[j]][0];
								b2(k1) += 1.0 / (abs(mesh.point(verts[i])[0] - mesh.point(verts[j])[0]) + abs(mesh.point(verts[i])[1] - mesh.point(verts[j])[1]) + abs(mesh.point(verts[i])[2] - mesh.point(verts[j])[2])) / sum_w*new_position[verts[j]][1];
								break;
							case parameterize_shape_preserving:
								int idx = 0;
								for (auto it = mesh.vv_begin(verts[i]); it != mesh.vv_end(verts[i]); ++it)
								{
									if (verts[j] == it)
									{
										break;
									}
									idx++;
								}
								b1(k1) += AverageWeight[idx] * new_position[verts[j]][0];
								b2(k1) += AverageWeight[idx] * new_position[verts[j]][1];
								break;
							}
						}
					}
				}
				k2 = -1;
			}
		}

		for (int i = 0; i < row.length(); i++)
		{
			triplets.push_back(Triplet<double>(row[i], column[i], value[i]));
		}
		SparseMatrix<double> A(n, n);
		A.setFromTriplets(triplets.begin(), triplets.end());
		linearSolver.compute(A);

		//��С�������
		VectorXd x1 = linearSolver.solve(b1);
		VectorXd x2 = linearSolver.solve(b2);

		if (linearSolver.info() != Success)
		{
			printf("Solving failed!\n");
			return;
		}

		if (!mesh.has_vertex_normals())
		{
			mesh.request_vertex_normals();
		}
		if (!mesh.has_face_normals())
		{
			mesh.request_face_normals();
		}
		if (!mesh.has_vertex_texcoords2D())
		{
			mesh.request_vertex_texcoords2D();
		}

		//��������
		k1 = -1;
		for (size_t i = 0; i != verts.size(); ++i)
		{
			if (!mesh.is_boundary(verts[i]))
			{
				k1++;
				mesh.set_texcoord2D(verts[i], OpenMesh::Vec2f(x1(k1), x2(k1)));
				//mesh.set_point(verts[i], OpenMesh::Vec3f(x1(k1), x2(k1), 0));
			}
			else
			{
				mesh.set_texcoord2D(verts[i], OpenMesh::Vec2f(new_position[verts[i]][0], new_position[verts[i]][1]));
				//mesh.set_point(verts[i], OpenMesh::Vec3f(new_position[verts[i]][0], new_position[verts[i]][1],0));
			}
		}

		updateGL();
		std::cout << "Successfully edited!" << std::endl;
	}
	else
	{
		QMessageBox::about(this, tr("Warning"), tr("Please read an obj file first!"));
	}
}

void RenderingWidget::DrawPoints(bool bv)
{
	if (!bv || mesh.vertices_empty())
		return;
	if (mesh.n_vertices() == 0)
	{
		return;
	}

	glBegin(GL_POINTS);
	for (MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it) 
	{
		glVertex3fv(mesh.point(*v_it).data());
	}
	glEnd();
}

void RenderingWidget::DrawEdge(bool bv)
{
	if (!bv || mesh.vertices_empty())
		return;

	if (mesh.n_faces() == 0)
	{
		return;
	}

	glBegin(GL_LINES);
	for (MyMesh::HalfedgeIter he_it = mesh.halfedges_begin(); he_it != mesh.halfedges_end(); ++he_it) 
	{
		glVertex3fv(mesh.point(mesh.from_vertex_handle(*he_it)).data());
		glVertex3fv(mesh.point(mesh.to_vertex_handle(*he_it)).data());
	}
	glEnd();
}

void RenderingWidget::DrawFace(bool bv)
{
	if (!bv || mesh.vertices_empty())
		return;

	if (mesh.n_faces() == 0)
	{
		return;
	}

	if (!mesh.has_vertex_normals())
	{
		mesh.request_vertex_normals();
	}
	if (!mesh.has_face_normals())
	{
		mesh.request_face_normals();
	}

	for (MyMesh::FaceIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it) 
	{
		glBegin(GL_TRIANGLES);
		for (MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*f_it); fv_it.is_valid(); ++fv_it)
		{
			glNormal3fv(mesh.normal(*fv_it).data());
			glVertex3fv(mesh.point(*fv_it).data());
			//glVertex3f(mesh.point(*fv_it)[0], mesh.point(*fv_it)[1], mesh.point(*fv_it)[2]);  
		}
		glEnd();
	}
}

void RenderingWidget::DrawTexture(bool bv)
{
	if (!bv)
		return;
	if (mesh.n_faces() == 0 || !is_load_texture_)
		return;

	if (!mesh.has_vertex_normals())
	{
		mesh.request_vertex_normals();
	}
	if (!mesh.has_face_normals())
	{
		mesh.request_face_normals();
	}
	if (!mesh.has_vertex_texcoords2D())
	{
		mesh.request_vertex_texcoords2D();
	}

	glBindTexture(GL_TEXTURE_2D, texture_[0]);
	glBegin(GL_TRIANGLES);

	for (MyMesh::FaceIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it)
	{
		for (auto h_it = mesh.fh_begin(f_it); h_it != mesh.fh_end(f_it); ++h_it)
		{
			glTexCoord2fv(mesh.texcoord2D(mesh.from_vertex_handle(h_it)).data());
			glNormal3fv(mesh.normal(mesh.from_vertex_handle(h_it)).data());
			glVertex3fv(mesh.point(mesh.from_vertex_handle(h_it)).data());
		}
	}

	glEnd();
}
