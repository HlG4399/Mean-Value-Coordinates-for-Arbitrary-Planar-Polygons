#ifndef MINIMESHFRAME_H
#define MINIMESHFRAME_H

#include <QtWidgets/QMainWindow>
#include "ui_minimeshframe.h"

class MiniMeshFrame : public QMainWindow
{
	Q_OBJECT

public:
	MiniMeshFrame(QWidget *parent = 0);
	~MiniMeshFrame();

private:
	Ui::MiniMeshFrameClass ui;
};

#endif // MINIMESHFRAME_H
