/****************************************************************************
** Meta object code from reading C++ file 'renderingwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../renderingwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'renderingwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_RenderingWidget_t {
    QByteArrayData data[32];
    char stringdata0[467];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RenderingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RenderingWidget_t qt_meta_stringdata_RenderingWidget = {
    {
QT_MOC_LITERAL(0, 0, 15), // "RenderingWidget"
QT_MOC_LITERAL(1, 16, 8), // "meshInfo"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 12), // "operatorInfo"
QT_MOC_LITERAL(4, 39, 13), // "SetBackground"
QT_MOC_LITERAL(5, 53, 8), // "ReadMesh"
QT_MOC_LITERAL(6, 62, 9), // "WriteMesh"
QT_MOC_LITERAL(7, 72, 11), // "LoadTexture"
QT_MOC_LITERAL(8, 84, 15), // "Minimal_Surface"
QT_MOC_LITERAL(9, 100, 22), // "Minimal_Surface_Global"
QT_MOC_LITERAL(10, 123, 10), // "IsNeighbor"
QT_MOC_LITERAL(11, 134, 20), // "MyMesh::VertexHandle"
QT_MOC_LITERAL(12, 155, 3), // "it1"
QT_MOC_LITERAL(13, 159, 3), // "idx"
QT_MOC_LITERAL(14, 163, 21), // "ParameterBorderVertex"
QT_MOC_LITERAL(15, 185, 34), // "std::vector<MyMesh::VertexHan..."
QT_MOC_LITERAL(16, 220, 22), // "temp_m_BorderVertexIdx"
QT_MOC_LITERAL(17, 243, 20), // "Parameterize_Uniform"
QT_MOC_LITERAL(18, 264, 5), // "Sum_W"
QT_MOC_LITERAL(19, 270, 1), // "p"
QT_MOC_LITERAL(20, 272, 21), // "Parameterize_Specific"
QT_MOC_LITERAL(21, 294, 22), // "Local_Parameterization"
QT_MOC_LITERAL(22, 317, 18), // "std::vector<float>"
QT_MOC_LITERAL(23, 336, 29), // "Parameterize_Shape_Preserving"
QT_MOC_LITERAL(24, 366, 12), // "Parameterize"
QT_MOC_LITERAL(25, 379, 14), // "CheckDrawPoint"
QT_MOC_LITERAL(26, 394, 2), // "bv"
QT_MOC_LITERAL(27, 397, 13), // "CheckDrawEdge"
QT_MOC_LITERAL(28, 411, 13), // "CheckDrawFace"
QT_MOC_LITERAL(29, 425, 10), // "CheckLight"
QT_MOC_LITERAL(30, 436, 16), // "CheckDrawTexture"
QT_MOC_LITERAL(31, 453, 13) // "CheckDrawAxes"

    },
    "RenderingWidget\0meshInfo\0\0operatorInfo\0"
    "SetBackground\0ReadMesh\0WriteMesh\0"
    "LoadTexture\0Minimal_Surface\0"
    "Minimal_Surface_Global\0IsNeighbor\0"
    "MyMesh::VertexHandle\0it1\0idx\0"
    "ParameterBorderVertex\0"
    "std::vector<MyMesh::VertexHandle>&\0"
    "temp_m_BorderVertexIdx\0Parameterize_Uniform\0"
    "Sum_W\0p\0Parameterize_Specific\0"
    "Local_Parameterization\0std::vector<float>\0"
    "Parameterize_Shape_Preserving\0"
    "Parameterize\0CheckDrawPoint\0bv\0"
    "CheckDrawEdge\0CheckDrawFace\0CheckLight\0"
    "CheckDrawTexture\0CheckDrawAxes"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RenderingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,  124,    2, 0x06 /* Public */,
       3,    1,  131,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  134,    2, 0x0a /* Public */,
       5,    0,  135,    2, 0x0a /* Public */,
       6,    0,  136,    2, 0x0a /* Public */,
       7,    0,  137,    2, 0x0a /* Public */,
       8,    0,  138,    2, 0x0a /* Public */,
       9,    0,  139,    2, 0x0a /* Public */,
      10,    2,  140,    2, 0x0a /* Public */,
      14,    1,  145,    2, 0x0a /* Public */,
      17,    0,  148,    2, 0x0a /* Public */,
      18,    1,  149,    2, 0x0a /* Public */,
      20,    0,  152,    2, 0x0a /* Public */,
      21,    1,  153,    2, 0x0a /* Public */,
      23,    0,  156,    2, 0x0a /* Public */,
      24,    0,  157,    2, 0x0a /* Public */,
      25,    1,  158,    2, 0x0a /* Public */,
      27,    1,  161,    2, 0x0a /* Public */,
      28,    1,  164,    2, 0x0a /* Public */,
      29,    1,  167,    2, 0x0a /* Public */,
      30,    1,  170,    2, 0x0a /* Public */,
      31,    1,  173,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, 0x80000000 | 11, 0x80000000 | 11,   12,   13,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void,
    QMetaType::Double, QMetaType::Int,   19,
    QMetaType::Void,
    0x80000000 | 22, QMetaType::Int,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   26,
    QMetaType::Void, QMetaType::Bool,   26,

       0        // eod
};

void RenderingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RenderingWidget *_t = static_cast<RenderingWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->meshInfo((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->operatorInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->SetBackground(); break;
        case 3: _t->ReadMesh(); break;
        case 4: _t->WriteMesh(); break;
        case 5: _t->LoadTexture(); break;
        case 6: _t->Minimal_Surface(); break;
        case 7: _t->Minimal_Surface_Global(); break;
        case 8: { bool _r = _t->IsNeighbor((*reinterpret_cast< MyMesh::VertexHandle(*)>(_a[1])),(*reinterpret_cast< MyMesh::VertexHandle(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: _t->ParameterBorderVertex((*reinterpret_cast< std::vector<MyMesh::VertexHandle>(*)>(_a[1]))); break;
        case 10: _t->Parameterize_Uniform(); break;
        case 11: { double _r = _t->Sum_W((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 12: _t->Parameterize_Specific(); break;
        case 13: { std::vector<float> _r = _t->Local_Parameterization((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< std::vector<float>*>(_a[0]) = _r; }  break;
        case 14: _t->Parameterize_Shape_Preserving(); break;
        case 15: _t->Parameterize(); break;
        case 16: _t->CheckDrawPoint((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->CheckDrawEdge((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->CheckDrawFace((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->CheckLight((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->CheckDrawTexture((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->CheckDrawAxes((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (RenderingWidget::*_t)(int , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&RenderingWidget::meshInfo)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (RenderingWidget::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&RenderingWidget::operatorInfo)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject RenderingWidget::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_RenderingWidget.data,
      qt_meta_data_RenderingWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *RenderingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RenderingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_RenderingWidget.stringdata0))
        return static_cast<void*>(const_cast< RenderingWidget*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int RenderingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void RenderingWidget::meshInfo(int _t1, int _t2, int _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void RenderingWidget::operatorInfo(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
