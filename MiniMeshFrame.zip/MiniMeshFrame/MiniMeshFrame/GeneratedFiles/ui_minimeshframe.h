/********************************************************************************
** Form generated from reading UI file 'minimeshframe.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MINIMESHFRAME_H
#define UI_MINIMESHFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MiniMeshFrameClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MiniMeshFrameClass)
    {
        if (MiniMeshFrameClass->objectName().isEmpty())
            MiniMeshFrameClass->setObjectName(QStringLiteral("MiniMeshFrameClass"));
        MiniMeshFrameClass->resize(600, 400);
        menuBar = new QMenuBar(MiniMeshFrameClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        MiniMeshFrameClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MiniMeshFrameClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MiniMeshFrameClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(MiniMeshFrameClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        MiniMeshFrameClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MiniMeshFrameClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MiniMeshFrameClass->setStatusBar(statusBar);

        retranslateUi(MiniMeshFrameClass);

        QMetaObject::connectSlotsByName(MiniMeshFrameClass);
    } // setupUi

    void retranslateUi(QMainWindow *MiniMeshFrameClass)
    {
        MiniMeshFrameClass->setWindowTitle(QApplication::translate("MiniMeshFrameClass", "MiniMeshFrame", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MiniMeshFrameClass: public Ui_MiniMeshFrameClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MINIMESHFRAME_H
