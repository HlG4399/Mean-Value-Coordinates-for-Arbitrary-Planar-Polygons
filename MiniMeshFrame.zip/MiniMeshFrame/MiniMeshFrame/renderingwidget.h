#ifndef RENDERINGWIDGET_H
#define RENDERINGWIDGET_H

#include <QGLWidget>
#include <QEvent>
#include <iostream>
#include "HE_mesh/Vec.h"
//#include "HE_mesh\Mesh3D.h"
#include <Eigen\Dense>
#include <Eigen\Core>
#include <Eigen\SparseCholesky>
#include <Eigen\SparseQR>
#include <OpenMesh\Core\IO\MeshIO.hh>
#include <OpenMesh\Core\Mesh\TriMesh_ArrayKernelT.hh>
#include <OpenMesh\Core\Mesh\Handles.hh>
#include <map>

typedef OpenMesh::TriMesh_ArrayKernelT<> MyMesh;

using trimesh::vec;
using trimesh::point;
using namespace Eigen;

class MainWindow;
class CArcBall;
class Mesh3D;

class RenderingWidget : public QGLWidget
{
	Q_OBJECT

public:
	RenderingWidget(QWidget *parent, MainWindow* mainwindow=0);
	~RenderingWidget();

protected:
	void initializeGL();
	void resizeGL(int w, int h);
	void paintGL();
	void timerEvent(QTimerEvent *e);

	// mouse events
	void mousePressEvent(QMouseEvent *e);
	void mouseMoveEvent(QMouseEvent *e);
	void mouseReleaseEvent(QMouseEvent *e);
	void mouseDoubleClickEvent(QMouseEvent *e);
	void wheelEvent(QWheelEvent *e);

public:
	void keyPressEvent(QKeyEvent *e);
	void keyReleaseEvent(QKeyEvent *e);

signals:
	void meshInfo(int, int, int);
	void operatorInfo(QString);

private:
	void Render();
	void SetLight();

	public slots:
	void SetBackground();
	void ReadMesh();
	void WriteMesh();
	void LoadTexture();
	void Minimal_Surface(void);//���þֲ������켫С����
	void Minimal_Surface_Global(void);//����ȫ�ַ����켫С����
	bool IsNeighbor(MyMesh::VertexHandle it1, MyMesh::VertexHandle idx);//Ѱ���ڵ�
	void ParameterBorderVertex(std::vector<MyMesh::VertexHandle>& temp_m_BorderVertexIdx);//�߽綥�������
	void Parameterize_Uniform(void);//uniform������
	double Sum_W(int p);//�����ڱ߱߳��ĵ���֮��
	void Parameterize_Specific(void);//specific������
	std::vector<float> Local_Parameterization(int p);//�ֲ�������
	void Parameterize_Shape_Preserving(void);//shape-preserving������
	void Parameterize(void);//���������

	void CheckDrawPoint(bool bv);
	void CheckDrawEdge(bool bv);
	void CheckDrawFace(bool bv);
	void CheckLight(bool bv);
	void CheckDrawTexture(bool bv);
	void CheckDrawAxes(bool bv);

private:
	//std::vector<HE_vert*>* Extract_Boundary(std::vector<HE_vert*> boundary_points);//��ȡ�߽�
	void DrawAxes(bool bv);
	void DrawPoints(bool);
	void DrawEdge(bool);
	void DrawFace(bool);
	void DrawTexture(bool);

public:
	MainWindow					*ptr_mainwindow_;
	CArcBall					*ptr_arcball_;
	MyMesh						mesh;

	// Texture
	GLuint						texture_[1];
	bool						is_load_texture_;

	// eye
	GLfloat						eye_distance_;
	point						eye_goal_;
	vec							eye_direction_;
	QPoint						current_position_;

	// Render information
	bool						is_draw_point_;
	bool						is_draw_edge_;
	bool						is_draw_face_;
	bool						is_draw_texture_;
	bool						has_lighting_;
	bool						is_draw_axes_;
	enum ParameterizeType
	{
		parameterize_uniform=0,
		parameterize_specific=1,
		parameterize_shape_preserving=2
	};
	ParameterizeType parameterizetype=parameterize_uniform;
	std::vector<MyMesh::VertexHandle> verts;
	std::map<MyMesh::VertexHandle, OpenMesh::DefaultTraits::Point> new_position;
	Eigen::SparseQR<Eigen::SparseMatrix<double>, Eigen::COLAMDOrdering<int>> linearSolver;

private:
	
};

#endif // RENDERINGWIDGET_H
