#pragma once
#include <QWidget>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include "Eigen\Dense"

using namespace Eigen;

QT_BEGIN_NAMESPACE
class QImage;
class QPainter;
QT_END_NAMESPACE

class ImageWidget :
	public QWidget
{
	Q_OBJECT

public:
	ImageWidget(void);
	~ImageWidget(void);

protected:
	void paintEvent(QPaintEvent *paintevent);

	public slots:
	// File IO
	void Open();												// Open an image file, support ".bmp, .png, .jpg" format
	void Save();												// Save image to current file
	void SaveAs();												// Save image to another file

																// Image processing
	void Invert();												// Invert pixel value in image
	void Mirror(bool horizontal = false, bool vertical = true);		// Mirror image vertically or horizontally
	void TurnGray();											// Turn image to gray-scale map
	void Restore();												// Restore image to origin
	void mousePressEvent(QMouseEvent *event);
	void mouseReleaseEvent(QMouseEvent *event);
	void Control_Points();
	double distance(QPointF  point, int i);

	void  IDW();
	double w_i_IDW(QPointF  point, int i);
	double delta_IDW(QPointF  point, int i);
	QPointF  f_i_IDW(QPointF  point, int i);
	QPointF  f_IDW(QPointF  point);

	void RBF();
	QPointF alpha_i_RBF(VectorXd x1, VectorXd x2, int i);
	double r_i_RBF(int i);
	double f_i_RBF(QPointF  point, int i);
	QPointF f_RBF(QPointF  point);

private:
	cv::Mat										image_mat_;
	cv::Mat										image_mat_backup_;
	QVector<QPointF> points_p, points_q;
	double u = 1.0;
	bool is_control_points = false;
};

