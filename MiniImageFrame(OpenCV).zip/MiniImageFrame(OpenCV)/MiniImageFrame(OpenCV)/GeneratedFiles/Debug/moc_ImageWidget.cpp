/****************************************************************************
** Meta object code from reading C++ file 'ImageWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ImageWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ImageWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ImageWidget_t {
    QByteArrayData data[32];
    char stringdata0[255];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ImageWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ImageWidget_t qt_meta_stringdata_ImageWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ImageWidget"
QT_MOC_LITERAL(1, 12, 4), // "Open"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 4), // "Save"
QT_MOC_LITERAL(4, 23, 6), // "SaveAs"
QT_MOC_LITERAL(5, 30, 6), // "Invert"
QT_MOC_LITERAL(6, 37, 6), // "Mirror"
QT_MOC_LITERAL(7, 44, 10), // "horizontal"
QT_MOC_LITERAL(8, 55, 8), // "vertical"
QT_MOC_LITERAL(9, 64, 8), // "TurnGray"
QT_MOC_LITERAL(10, 73, 7), // "Restore"
QT_MOC_LITERAL(11, 81, 15), // "mousePressEvent"
QT_MOC_LITERAL(12, 97, 12), // "QMouseEvent*"
QT_MOC_LITERAL(13, 110, 5), // "event"
QT_MOC_LITERAL(14, 116, 17), // "mouseReleaseEvent"
QT_MOC_LITERAL(15, 134, 14), // "Control_Points"
QT_MOC_LITERAL(16, 149, 8), // "distance"
QT_MOC_LITERAL(17, 158, 5), // "point"
QT_MOC_LITERAL(18, 164, 1), // "i"
QT_MOC_LITERAL(19, 166, 3), // "IDW"
QT_MOC_LITERAL(20, 170, 7), // "w_i_IDW"
QT_MOC_LITERAL(21, 178, 9), // "delta_IDW"
QT_MOC_LITERAL(22, 188, 7), // "f_i_IDW"
QT_MOC_LITERAL(23, 196, 5), // "f_IDW"
QT_MOC_LITERAL(24, 202, 3), // "RBF"
QT_MOC_LITERAL(25, 206, 11), // "alpha_i_RBF"
QT_MOC_LITERAL(26, 218, 8), // "VectorXd"
QT_MOC_LITERAL(27, 227, 2), // "x1"
QT_MOC_LITERAL(28, 230, 2), // "x2"
QT_MOC_LITERAL(29, 233, 7), // "r_i_RBF"
QT_MOC_LITERAL(30, 241, 7), // "f_i_RBF"
QT_MOC_LITERAL(31, 249, 5) // "f_RBF"

    },
    "ImageWidget\0Open\0\0Save\0SaveAs\0Invert\0"
    "Mirror\0horizontal\0vertical\0TurnGray\0"
    "Restore\0mousePressEvent\0QMouseEvent*\0"
    "event\0mouseReleaseEvent\0Control_Points\0"
    "distance\0point\0i\0IDW\0w_i_IDW\0delta_IDW\0"
    "f_i_IDW\0f_IDW\0RBF\0alpha_i_RBF\0VectorXd\0"
    "x1\0x2\0r_i_RBF\0f_i_RBF\0f_RBF"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ImageWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x0a /* Public */,
       3,    0,  130,    2, 0x0a /* Public */,
       4,    0,  131,    2, 0x0a /* Public */,
       5,    0,  132,    2, 0x0a /* Public */,
       6,    2,  133,    2, 0x0a /* Public */,
       6,    1,  138,    2, 0x2a /* Public | MethodCloned */,
       6,    0,  141,    2, 0x2a /* Public | MethodCloned */,
       9,    0,  142,    2, 0x0a /* Public */,
      10,    0,  143,    2, 0x0a /* Public */,
      11,    1,  144,    2, 0x0a /* Public */,
      14,    1,  147,    2, 0x0a /* Public */,
      15,    0,  150,    2, 0x0a /* Public */,
      16,    2,  151,    2, 0x0a /* Public */,
      19,    0,  156,    2, 0x0a /* Public */,
      20,    2,  157,    2, 0x0a /* Public */,
      21,    2,  162,    2, 0x0a /* Public */,
      22,    2,  167,    2, 0x0a /* Public */,
      23,    1,  172,    2, 0x0a /* Public */,
      24,    0,  175,    2, 0x0a /* Public */,
      25,    3,  176,    2, 0x0a /* Public */,
      29,    1,  183,    2, 0x0a /* Public */,
      30,    2,  186,    2, 0x0a /* Public */,
      31,    1,  191,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,    7,    8,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Double, QMetaType::QPointF, QMetaType::Int,   17,   18,
    QMetaType::Void,
    QMetaType::Double, QMetaType::QPointF, QMetaType::Int,   17,   18,
    QMetaType::Double, QMetaType::QPointF, QMetaType::Int,   17,   18,
    QMetaType::QPointF, QMetaType::QPointF, QMetaType::Int,   17,   18,
    QMetaType::QPointF, QMetaType::QPointF,   17,
    QMetaType::Void,
    QMetaType::QPointF, 0x80000000 | 26, 0x80000000 | 26, QMetaType::Int,   27,   28,   18,
    QMetaType::Double, QMetaType::Int,   18,
    QMetaType::Double, QMetaType::QPointF, QMetaType::Int,   17,   18,
    QMetaType::QPointF, QMetaType::QPointF,   17,

       0        // eod
};

void ImageWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ImageWidget *_t = static_cast<ImageWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Open(); break;
        case 1: _t->Save(); break;
        case 2: _t->SaveAs(); break;
        case 3: _t->Invert(); break;
        case 4: _t->Mirror((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 5: _t->Mirror((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->Mirror(); break;
        case 7: _t->TurnGray(); break;
        case 8: _t->Restore(); break;
        case 9: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 10: _t->mouseReleaseEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 11: _t->Control_Points(); break;
        case 12: { double _r = _t->distance((*reinterpret_cast< QPointF(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 13: _t->IDW(); break;
        case 14: { double _r = _t->w_i_IDW((*reinterpret_cast< QPointF(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 15: { double _r = _t->delta_IDW((*reinterpret_cast< QPointF(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 16: { QPointF _r = _t->f_i_IDW((*reinterpret_cast< QPointF(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = _r; }  break;
        case 17: { QPointF _r = _t->f_IDW((*reinterpret_cast< QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = _r; }  break;
        case 18: _t->RBF(); break;
        case 19: { QPointF _r = _t->alpha_i_RBF((*reinterpret_cast< VectorXd(*)>(_a[1])),(*reinterpret_cast< VectorXd(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = _r; }  break;
        case 20: { double _r = _t->r_i_RBF((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 21: { double _r = _t->f_i_RBF((*reinterpret_cast< QPointF(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 22: { QPointF _r = _t->f_RBF((*reinterpret_cast< QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject ImageWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ImageWidget.data,
      qt_meta_data_ImageWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ImageWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ImageWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ImageWidget.stringdata0))
        return static_cast<void*>(const_cast< ImageWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int ImageWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
