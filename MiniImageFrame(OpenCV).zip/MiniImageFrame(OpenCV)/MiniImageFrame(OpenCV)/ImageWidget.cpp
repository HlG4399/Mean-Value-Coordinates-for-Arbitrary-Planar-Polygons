#include "ImageWidget.h"
#include <QImage>
#include <QPainter>
#include <QtWidgets> 
#include <iostream>

using std::cout;
using std::endl;

ImageWidget::ImageWidget(void)
{

}


ImageWidget::~ImageWidget(void)
{
}

void ImageWidget::paintEvent(QPaintEvent *paintevent)
{
	QPainter painter(this);
	//painter.begin(this);

	// Draw background
	painter.setBrush(Qt::lightGray);
	QRect back_rect(0, 0, width(), height());
	painter.drawRect(back_rect);

	// Draw image
	QImage image_show = QImage((unsigned char *)(image_mat_.data), image_mat_.cols, image_mat_.rows, image_mat_.step, QImage::Format_RGB888);
	QRect rect = QRect((width() - image_show.width()) / 2, (height() - image_show.height()) / 2, image_show.width(), image_show.height());
	painter.drawImage(rect, image_show);

	if (points_q.size() > 0)
	{
		painter.setRenderHint(QPainter::Antialiasing, true);
		QPen pen(Qt::green, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
		painter.setPen(pen);
		for (size_t i = 0; i < points_q.size(); i++)
		{
			painter.drawLine(points_p[i], points_q[i]);
		}
	}

	//painter.end();
	update();
}

void ImageWidget::Open()
{
	// Open file
	QString fileName = QFileDialog::getOpenFileName(this, tr("Read Image"), "E://", tr("Images(*.bmp *.png *.jpg)"));

	// Load file
	if (!fileName.isEmpty())
	{
		image_mat_ = cv::imread(fileName.toLatin1().data());
		cv::cvtColor(image_mat_, image_mat_,CV_BGR2RGB );
		image_mat_backup_ = image_mat_.clone();
	}
	update();
}

void ImageWidget::Save()
{
	SaveAs();
}   

void ImageWidget::SaveAs()
{
	QString filename = QFileDialog::getSaveFileName(this, tr("Save Image"), ".", tr("Images(*.bmp *.png *.jpg)"));
	if (filename.isNull())
	{
		return;
	}

	cv::Mat image_save;
	cvtColor(image_mat_, image_save, CV_RGB2BGR);
	imwrite(filename.toLatin1().data(), image_save);
}

void ImageWidget::Invert()
{
	cv::MatIterator_<cv::Vec3b> iter, iterend;
	for (iter = image_mat_.begin<cv::Vec3b>(), iterend = image_mat_.end<cv::Vec3b>(); iter != iterend; ++iter)
	{
		(*iter)[0] = 255 - (*iter)[0];
		(*iter)[1] = 255 - (*iter)[1];
		(*iter)[2] = 255 - (*iter)[2];
	}

	update();
}

void ImageWidget::Mirror(bool ishorizontal, bool isvertical)
{
	int width = image_mat_.cols;
	int height = image_mat_.rows;

	if (ishorizontal)
	{
		if (isvertical)
		{
			for (int i = 0; i<width; i++)
			{
				for (int j = 0; j<height; j++)
				{
					image_mat_.at<cv::Vec3b>(j, i) = image_mat_backup_.at<cv::Vec3b>(height - 1 - j, width - 1 - i);
				}
			}
		}
		else
		{
			for (int i = 0; i<width; i++)
			{
				for (int j = 0; j<height; j++)
				{
					image_mat_.at<cv::Vec3b>(j, i) = image_mat_backup_.at<cv::Vec3b>(j, width - 1 - i);
				}
			}
		}

	}
	else
	{
		if (isvertical)
		{
			for (int i = 0; i<width; i++)
			{
				for (int j = 0; j<height; j++)
				{
					image_mat_.at<cv::Vec3b>(j, i) = image_mat_backup_.at<cv::Vec3b>(height - 1 - j, i);
				}
			}
		}
	}

	update();
}

void ImageWidget::TurnGray()
{
	cv::MatIterator_<cv::Vec3b> iter, iterend;
	for (iter = image_mat_.begin<cv::Vec3b>(), iterend = image_mat_.end<cv::Vec3b>(); iter != iterend; ++iter)
	{
		int itmp = ((*iter)[0] + (*iter)[1] + (*iter)[2]) / 3;
		(*iter)[0] = itmp;
		(*iter)[1] = itmp;
		(*iter)[2] = itmp;
	}

	update();
}

void ImageWidget::Restore()
{
	image_mat_ = image_mat_backup_.clone();
	points_p.clear();
	points_q.clear();
	is_control_points = false;
	update();
}

void ImageWidget::mousePressEvent(QMouseEvent *event)
{
	if (image_mat_.cols != 0 && is_control_points)
	{
		if (Qt::LeftButton == event->button())
		{
			if (event->pos().rx() >= (width() - image_mat_backup_.cols) / 2 && event->pos().rx() <= (width() + image_mat_backup_.cols) / 2 && event->pos().ry() >= (height() - image_mat_backup_.rows) / 2 && event->pos().ry() <= (height() + image_mat_backup_.rows) / 2)
			{
				points_p.push_back(event->pos());
			}
		}
	}
}

void ImageWidget::mouseReleaseEvent(QMouseEvent *event)
{
	if (image_mat_.cols != 0 && points_p.size()>0 && is_control_points)
	{
		if (event->pos().rx() >= (width() - image_mat_backup_.cols) / 2 && event->pos().rx() <= (width() + image_mat_backup_.cols) / 2 && event->pos().ry() >= (height() - image_mat_backup_.rows) / 2 && event->pos().ry() <= (height() + image_mat_backup_.rows) / 2)
		{
			points_q.push_back(event->pos());
		}
		if (points_p.size() > points_q.size())
		{
			points_p.pop_back();
		}
		if (points_p.size() < points_q.size())
		{
			points_q.pop_back();
		}
	}
}

void ImageWidget::Control_Points()
{
	is_control_points = true;
}

double ImageWidget::distance(QPointF point, int i)
{
	return sqrt((point.rx() - points_p[i].rx())*(point.rx() - points_p[i].rx()) + (point.ry() - points_p[i].ry())*(point.ry() - points_p[i].ry()))*1.0;
}

void  ImageWidget::IDW()
{
	if (points_q.size() > 0)
	{
		for (int i = 0; i < image_mat_.cols; i++)
		{
			for (int j = 0; j < image_mat_.rows; j++)
			{
				image_mat_.at<cv::Vec3b>(j, i) = cv::Vec3b(0, 0, 0);
			}
		}
		QVector<QPoint> results;
		for (int i = 0; i < image_mat_backup_.cols; i++)
		{
			for (int j = 0; j < image_mat_backup_.rows; j++)
			{
				QPointF result = f_IDW(QPointF(i + (width() - image_mat_backup_.cols) / 2, j + (height() - image_mat_backup_.rows) / 2));
				if (result.rx() >= (width() - image_mat_backup_.cols) / 2 && result.rx() < (width() + image_mat_backup_.cols) / 2 && result.ry() >= (height() - image_mat_backup_.rows) / 2 && result.ry() < (height() + image_mat_backup_.rows) / 2)
				{
					image_mat_.at<cv::Vec3b>((int)result.ry() - (height() - image_mat_backup_.rows) / 2, (int)result.rx() - (width() - image_mat_backup_.cols) / 2) = image_mat_backup_.at<cv::Vec3b>(j, i);
					results.push_back(QPoint((int)result.rx() - (width() - image_mat_backup_.cols) / 2, (int)result.ry() - (height() - image_mat_backup_.rows) / 2));
				}
			}
		}
		//��ֵ���ն�
		int num_adjacent_black_pixels = 0;//���ں�ɫ���ص�����������ں�ɫ���ص�������࣬���ж������ص�λ��ͼ���ⲿ������������д�����
		int r = 0, g = 0, b = 0;
		for (int i = 0; i < image_mat_backup_.cols; i++)
		{
			for (int j = 0; j < image_mat_backup_.rows; j++)
			{
				QVector<QPoint>::iterator iter = std::find(results.begin(), results.end(), QPoint(i,j));//���ص���һ��������ָ��
				if (iter != results.end())
				{
					continue;
				}
				if (i - 1 >= 0 && j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i )[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i )[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols && j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i+1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j , i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j , i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols)
				{
					r += image_mat_.at<cv::Vec3b>(j , i + 1)[2];
					g += image_mat_.at<cv::Vec3b>(j , i + 1)[1];
					b += image_mat_.at<cv::Vec3b>(j , i + 1)[0];
					if (image_mat_.at<cv::Vec3b>(j, i + 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i - 1 >= 0 && j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j+1, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j+1, i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j+1, i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j+1, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j + 1, i )[2];
					g += image_mat_.at<cv::Vec3b>(j + 1, i)[1];
					b += image_mat_.at<cv::Vec3b>(j + 1, i )[0];
					if (image_mat_.at<cv::Vec3b>(j + 1, i) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols&&j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j + 1, i+1)[2];
					g += image_mat_.at<cv::Vec3b>(j + 1, i+1)[1];
					b += image_mat_.at<cv::Vec3b>(j + 1, i+1)[0];
					if (image_mat_.at<cv::Vec3b>(j + 1, i+1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (num_adjacent_black_pixels < 6)
				{
					image_mat_.at<cv::Vec3b>(j, i) = cv::Vec3b(b / (8 - num_adjacent_black_pixels),g / (8 - num_adjacent_black_pixels), r / (8 - num_adjacent_black_pixels));
				}
				num_adjacent_black_pixels = 0;
				r = 0, g = 0, b = 0;
			}
		}
		points_p.clear();
		points_q.clear(); 
		is_control_points = false;
		update();
	}
	else
	{
		QMessageBox::about(this, tr("Warning"), tr("Please select the control points first."));
	}
}

double ImageWidget::w_i_IDW(QPointF point, int i)
{
	double result = 0;
	if (point == points_p[i])
	{
		return 1;
	}
	for (size_t j = 0; j < points_p.size(); j++)
	{
		result += delta_IDW(point, j);
	}
	result = delta_IDW(point, i) / result;
	return result;
}

double ImageWidget::delta_IDW(QPointF point, int i)
{
	return 1.0 / pow(distance(point, i), u);
}

QPointF ImageWidget::f_i_IDW(QPointF point, int i)
{
	QPointF result;
	result.rx() = points_q[i].rx() + point.rx() - points_p[i].rx();
	result.ry() = points_q[i].ry() + point.ry() - points_p[i].ry();
	return result;
}

QPointF ImageWidget::f_IDW(QPointF point)
{
	QPoint result(0, 0);
	for (size_t i = 0; i < points_p.size(); i++)
	{
		result.rx() += f_i_IDW(point, i).rx()*w_i_IDW(point, i);
		result.ry() += f_i_IDW(point, i).ry()*w_i_IDW(point, i);
	}
	return result;
}

void ImageWidget::RBF()
{
	if (points_q.size() > 0)
	{
		for (int i = 0; i < image_mat_.cols; i++)
		{
			for (int j = 0; j < image_mat_.rows; j++)
			{
				image_mat_.at<cv::Vec3b>(j, i) = cv::Vec3b(0, 0, 0);
			}
		}
		QVector<QPoint> results;
		for (int i = 0; i <image_mat_backup_.cols; i++)
		{
			for (int j = 0; j < image_mat_backup_.rows; j++)
			{
				QPointF result = f_RBF(QPointF(QPointF(i + (width() - image_mat_backup_.cols) / 2, j + (height() - image_mat_backup_.rows) / 2)));
				if (result.rx() >= (width() - image_mat_backup_.cols) / 2 && result.rx() < (width() + image_mat_backup_.cols) / 2 && result.ry() >= (height() - image_mat_backup_.rows) / 2 && result.ry() < (height() + image_mat_backup_.rows) / 2)
				{
					image_mat_.at<cv::Vec3b>((int)result.ry() - (height() - image_mat_backup_.rows) / 2, (int)result.rx() - (width() - image_mat_backup_.cols) / 2) = image_mat_backup_.at<cv::Vec3b>(j, i);
					results.push_back(QPoint((int)result.rx() - (width() - image_mat_backup_.cols) / 2, (int)result.ry() - (height() - image_mat_backup_.rows) / 2));
				}
			}
		}
		//��ֵ���ն�
		int num_adjacent_black_pixels = 0;//���ں�ɫ���ص�����������ں�ɫ���ص�������࣬���ж������ص�λ��ͼ���ⲿ������������д�����
		int r = 0, g = 0, b = 0;
		for (int i = 0; i < image_mat_backup_.cols; i++)
		{
			for (int j = 0; j < image_mat_backup_.rows; j++)
			{
				QVector<QPoint>::iterator iter = std::find(results.begin(), results.end(), QPoint(i, j));//���ص���һ��������ָ��
				if (iter != results.end())
				{
					continue;
				}
				if (i - 1 >= 0 && j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i)[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i)[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols && j - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[2];
					g += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[1];
					b += image_mat_.at<cv::Vec3b>(j - 1, i + 1)[0];
					if (image_mat_.at<cv::Vec3b>(j - 1, i + 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i - 1 >= 0)
				{
					r += image_mat_.at<cv::Vec3b>(j, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j, i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j, i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols)
				{
					r += image_mat_.at<cv::Vec3b>(j, i + 1)[2];
					g += image_mat_.at<cv::Vec3b>(j, i + 1)[1];
					b += image_mat_.at<cv::Vec3b>(j, i + 1)[0];
					if (image_mat_.at<cv::Vec3b>(j, i + 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i - 1 >= 0 && j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j + 1, i - 1)[2];
					g += image_mat_.at<cv::Vec3b>(j + 1, i - 1)[1];
					b += image_mat_.at<cv::Vec3b>(j + 1, i - 1)[0];
					if (image_mat_.at<cv::Vec3b>(j + 1, i - 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j + 1, i)[2];
					g += image_mat_.at<cv::Vec3b>(j + 1, i)[1];
					b += image_mat_.at<cv::Vec3b>(j + 1, i)[0];
					if (image_mat_.at<cv::Vec3b>(j + 1, i) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (i + 1 < image_mat_backup_.cols&&j + 1 < image_mat_backup_.rows)
				{
					r += image_mat_.at<cv::Vec3b>(j + 1, i + 1)[2];
					g += image_mat_.at<cv::Vec3b>(j + 1, i + 1)[1];
					b += image_mat_.at<cv::Vec3b>(j + 1, i + 1)[0];
					if (image_mat_.at<cv::Vec3b>(j + 1, i + 1) == cv::Vec3b(0, 0, 0))
					{
						num_adjacent_black_pixels++;
					}
				}
				if (num_adjacent_black_pixels < 4)
				{				
					image_mat_.at<cv::Vec3b>(j, i) = cv::Vec3b(b / (8 - num_adjacent_black_pixels), g / (8 - num_adjacent_black_pixels), r / (8 - num_adjacent_black_pixels));
				}
				num_adjacent_black_pixels = 0;
				r = 0, g = 0, b = 0;
			}
		}
		points_p.clear();
		points_q.clear();
		is_control_points = false;
		update();
	}
	else
	{
		QMessageBox::about(this, tr("Warning"), tr("Please select the control points first."));
	}
}

QPointF ImageWidget::alpha_i_RBF(VectorXd x1, VectorXd x2, int i)
{
	return QPointF(x1(i), x2(i));
}

double ImageWidget::r_i_RBF(int i)
{
	double min;
	//min = distance(points_p[i], 0);
	//for (int j = 0; j < points_p.size(); j++)
	//{
	//	if (j != 0 && j!=i)
	//	{
	//		if (min > distance(points_p[i], j))
	//		{
	//			min = distance(points_p[i], j);
	//		}
	//	}
	//}
	min = 10.0;
	return min;
}

double ImageWidget::f_i_RBF(QPointF  point, int i)
{
	return pow(distance(point, i)*distance(point, i) + r_i_RBF(i)*r_i_RBF(i), u / 2.0);
}

QPointF ImageWidget::f_RBF(QPointF  point)
{
	QPointF result(0, 0);
	MatrixXd A = MatrixXd::Ones(points_p.size(), points_p.size());
	VectorXd b1 = VectorXd::Ones(points_q.size());
	VectorXd b2 = VectorXd::Ones(points_q.size());
	for (int i = 0; i < points_p.size(); i++)
	{
		for (int j = 0; j< points_p.size(); j++)
		{
			A(i, j) = f_i_RBF(points_p[i], j);
		}
		b1(i) = points_q[i].rx() - points_p[i].rx();
		b2(i) = points_q[i].ry() - points_p[i].ry();
	}
	VectorXd x1 = A.ldlt().solve(b1);
	VectorXd x2 = A.ldlt().solve(b2);
	for (size_t i = 0; i < points_p.size(); i++)
	{
		result.rx() += alpha_i_RBF(x1, x2, i).rx()*f_i_RBF(point, i);
		result.ry() += alpha_i_RBF(x1, x2, i).ry()*f_i_RBF(point, i);
	}
	result.rx() += point.rx();
	result.ry() += point.ry();
	return result;
}